#include <Arduino.h>

void enter_bootloader(void)
{

  Serial.println("Bootloader mode");
  Serial.end();
  delay(200);


  void (*SysMemBootJump)(void);
  volatile uint32_t addr = 0x1FFFF000;
#if defined(USE_HAL_DRIVER)
  HAL_RCC_DeInit();
#endif /* defined(USE_HAL_DRIVER) */
#if defined(USE_STDPERIPH_DRIVER)
  RCC_DeInit();
#endif /* defined(USE_STDPERIPH_DRIVER) */

  SysTick->CTRL = 0;
  SysTick->LOAD = 0;
  SysTick->VAL = 0;

  __disable_irq();
  SysMemBootJump = (void (*)(void))(*((uint32_t *)(addr + 4)));
  __set_MSP(*(uint32_t *)addr);
  SysMemBootJump();
}