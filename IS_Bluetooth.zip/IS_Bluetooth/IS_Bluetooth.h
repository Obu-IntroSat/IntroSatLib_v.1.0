extern void enter_bootloader();
