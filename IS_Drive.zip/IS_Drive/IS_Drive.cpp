#if defined ( ESP8266 )
  #include <pgmspace.h>
#else
  #include <avr/pgmspace.h>
  //#include <util/delay.h>
#endif

#include <stdlib.h>

#include "IS_Drive.h"

void Drive::speed_control(uint8_t addr, uint8_t dir, uint16_t mot_speed)
    {
	uint8_t all_speed[3];
	all_speed[0] = dir;
	all_speed[1] = mot_speed ^ 0x0F;
	all_speed[2] = mot_speed  >> 8;

	Wire.beginTransmission(addr);
	Wire.write(all_speed, 3);
	Wire.endTransmission();
	delay(100);
    }
 
