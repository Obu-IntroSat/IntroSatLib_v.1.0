/*
  IS_Drive.h - Library for IntroSat's Motor.
  Created by Ksenya U. Yakushina, August 12, 2020.
  Released into the private domain.
*/

#ifndef _IS_DRIVE_H_
#define _IS_DRIVE_H_

#if ARDUINO >= 100
 #include <Arduino.h>
#else
 #include <WProgram.h>
#endif
#include <Wire.h>


class Drive
{
	public:
		void speed_control(uint8_t addr, uint8_t dir, uint16_t mot_speed);
};
	
#endif
