#if defined ( ESP8266 )
  #include <pgmspace.h>
#else
  #include <avr/pgmspace.h>
  //#include <util/delay.h>
#endif

#include <stdlib.h>

#include "IS_Sensors.h"

void Sensor::I2Cread(uint8_t Address, uint8_t Register, uint8_t Nbytes, uint8_t* Data)
    {
      Wire.beginTransmission(Address);
      Wire.write(Register);
      Wire.endTransmission();
 
      Wire.requestFrom(Address, Nbytes);
      uint8_t index=0;
      while (Wire.available())
      Data[index++]=Wire.read();
    }
    
void Sensor::I2CwriteByte(uint8_t Address, uint8_t Register, uint8_t Data)
    {
      Wire.beginTransmission(Address);
      Wire.write(Register);
      Wire.write(Data);
      Wire.endTransmission();
    }
 
