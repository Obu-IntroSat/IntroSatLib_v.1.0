/*
  IS_Sensors.h - Library for IntroSat's Sensors.
  Created by Ksenya U. Yakushina, July 09, 2020.
  Released into the private domain.
*/

#ifndef _IS_SENSORS_H_
#define _IS_SENSORS_H_

#if ARDUINO >= 100
 #include <Arduino.h>
#else
 #include <WProgram.h>
#endif
#include <Wire.h>


class Sensor
{
	public:
		void I2Cread(uint8_t Address, uint8_t Register, uint8_t Nbytes, uint8_t* Data);
		void I2CwriteByte(uint8_t Address, uint8_t Register, uint8_t Data);
};
	
#endif
